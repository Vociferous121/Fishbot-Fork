# Fishbot
World of Warcraft 1.12.1 Fishing Bot

Developed for educational purposes.

Note: 
- 100% safe on private servers
- Do not use on live servers - you have a high chance of a ban.
- Use at your own risk.

![alt tag](http://i.imgur.com/tDR66AP.png)